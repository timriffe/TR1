# Changes in this update
9 Aug 2018.  

*  `readHFDweb()` fixed, now relies on `hhtr` HT @jasonhilton
*  `readHMDweb()` fixed, now relies on `httr`




